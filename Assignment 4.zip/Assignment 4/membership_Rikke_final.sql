-- =========================================================
-- PURCHASE_MEMBERSHIP_PROC + Row-level trigger + Statement-level trigger
-- Schema: bergen
-- =========================================================

-- ---------------------------------------------------------
-- Cleanup
-- ---------------------------------------------------------
DROP TRIGGER IF EXISTS trg_check_membership_dates ON bergen.bought_membership;
DROP TRIGGER IF EXISTS trg_membership_insert_statement ON bergen.bought_membership;

DROP FUNCTION IF EXISTS bergen.check_membership_dates();
DROP FUNCTION IF EXISTS bergen.membership_insert_statement_trigger();
DROP FUNCTION IF EXISTS bergen.purchase_membership_sp(INT, VARCHAR, BOOLEAN, TIMESTAMPTZ, TIMESTAMPTZ);
DROP PROCEDURE IF EXISTS bergen.purchase_membership_proc;

DELETE FROM bergen.bought_membership WHERE membership_type = 'monthly';
DELETE FROM bergen.user_info WHERE email = 'ola@test.no';
DELETE FROM bergen.membership WHERE membership_type = 'monthly';

-- ---------------------------------------------------------
-- Test data for membership
-- ---------------------------------------------------------
INSERT INTO bergen.membership (membership_type, price, duration)
VALUES ('monthly', 299.00, 30);

-- ---------------------------------------------------------
-- Test data for user
-- ---------------------------------------------------------
INSERT INTO bergen.user_info (
    name,
    surname,
    email,
    date_of_birth,
    street,
    city,
    postal_code,
    state,
    total_trips
)
VALUES (
    'Ola',
    'Nordmann',
    'ola@test.no',
    '1990-01-01',
    'Testveien 1',
    'Bergen',
    5000,
    'NO',
    0
);

-- ---------------------------------------------------------
-- Stored procedure: PURCHASE_MEMBERSHIP_PROC
-- ---------------------------------------------------------
CREATE OR REPLACE PROCEDURE bergen.purchase_membership_proc(
    IN p_user_id INT,
    IN p_membership_type VARCHAR,
    IN p_is_active BOOLEAN,
    IN p_activation_time TIMESTAMPTZ DEFAULT NULL,
    INOUT p_purchase_id INT DEFAULT NULL
)
LANGUAGE plpgsql
AS $$
DECLARE
    v_duration INT;
    v_activation_time TIMESTAMPTZ;
    v_expiration_time TIMESTAMPTZ;
BEGIN
    -- Validate that membership type exists
    PERFORM 1
    FROM bergen.membership
    WHERE membership_type = p_membership_type;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Invalid membership type: % does not exist in bergen.membership', p_membership_type;
    END IF;

    -- Validate that user exists
    PERFORM 1
    FROM bergen.user_info
    WHERE user_id = p_user_id;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'User does not exist: user_id % was not found in bergen.user_info', p_user_id;
    END IF;

    -- Get duration from membership table
    SELECT duration
    INTO v_duration
    FROM bergen.membership
    WHERE membership_type = p_membership_type;

    -- Use current timestamp if activation time is not provided
    v_activation_time := COALESCE(p_activation_time, CURRENT_TIMESTAMP);

    -- Derive expiration time from activation_time + duration
    v_expiration_time := v_activation_time + (v_duration || ' days')::INTERVAL;

    -- Insert purchase
    INSERT INTO bergen.bought_membership (
        user_id,
        membership_type,
        is_active,
        purchase_time,
        activation_time,
        expiration_time
    )
    VALUES (
        p_user_id,
        p_membership_type,
        p_is_active,
        CURRENT_TIMESTAMP,
        v_activation_time,
        v_expiration_time
    )
    RETURNING purchase_id INTO p_purchase_id;

EXCEPTION
    WHEN unique_violation THEN
        RAISE EXCEPTION 'Duplicate value caused a unique violation while purchasing membership';
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Unexpected error in purchase_membership_proc: %', SQLERRM;
END;
$$;

-- ---------------------------------------------------------
-- Row-level trigger function
-- ---------------------------------------------------------
CREATE OR REPLACE FUNCTION bergen.check_membership_dates()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
    IF NEW.expiration_time <= NEW.activation_time THEN
        RAISE EXCEPTION 'Expiration time must be later than activation time';
    END IF;

    RETURN NEW;
END;
$$;

-- ---------------------------------------------------------
-- Row-level trigger
-- ---------------------------------------------------------
DROP TRIGGER IF EXISTS trg_check_membership_dates ON bergen.bought_membership;
CREATE TRIGGER trg_check_membership_dates
BEFORE INSERT OR UPDATE ON bergen.bought_membership
FOR EACH ROW
EXECUTE FUNCTION bergen.check_membership_dates();

-- ---------------------------------------------------------
-- Statement-level trigger function
-- ---------------------------------------------------------
CREATE OR REPLACE FUNCTION bergen.membership_insert_statement_trigger()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
    RAISE NOTICE 'Insert statement executed on bought_membership table';
    RETURN NULL;
END;
$$;

-- ---------------------------------------------------------
-- Statement-level trigger
-- ---------------------------------------------------------
DROP TRIGGER IF EXISTS trg_membership_insert_statement ON bergen.bought_membership;

CREATE TRIGGER trg_membership_insert_statement
AFTER INSERT ON bergen.bought_membership
FOR EACH STATEMENT
EXECUTE FUNCTION bergen.membership_insert_statement_trigger();

-- ---------------------------------------------------------
-- Test execution of PURCHASE_MEMBERSHIP_PROC
-- ---------------------------------------------------------
DO $$
DECLARE
    v_user_id INT;
    v_purchase_id INT;
BEGIN
    SELECT user_id
    INTO v_user_id
    FROM bergen.user_info
    WHERE email = 'ola@test.no';

    CALL bergen.purchase_membership_proc(
        v_user_id,
        'monthly',
        true,
        CURRENT_TIMESTAMP,
        v_purchase_id
    );

    RAISE NOTICE 'New purchase_id: %', v_purchase_id;
END $$;

-- ---------------------------------------------------------
-- Show result
-- ---------------------------------------------------------
SELECT * FROM bergen.bought_membership;
-- Cleanup

DROP TRIGGER IF EXISTS trg_check_year_acquired ON bergen.bike;
DROP TRIGGER IF EXISTS trg_bike_insert_statement ON bergen.bike;

DROP FUNCTION IF EXISTS bergen.create_bicycle_sp(VARCHAR, VARCHAR, INT);
DROP PROCEDURE IF EXISTS bergen.create_bicycle_proc(VARCHAR, VARCHAR, INT, INOUT VARCHAR);
DROP FUNCTION IF EXISTS bergen.check_year_acquired();
DROP FUNCTION IF EXISTS bergen.bike_insert_statement_trigger();

DELETE FROM bergen.bike;
DELETE FROM bergen.station_dock;
DELETE FROM bergen.station;
DELETE FROM bergen.bike_type;
DELETE FROM bergen.program;


-- =========================================
-- IS-309 Assignment
-- Stored procedure and triggers for bergen.bike
-- =========================================

-- 1. Test data setup

INSERT INTO bergen.program
(program_id, country_code, name, location, email, url, time_zone, phone)
VALUES
('P1', 'N', 'Test Program', 'Bergen', 'test@program.no', 'https://program.no', 'Europe/Oslo', '12345678');

INSERT INTO bergen.bike_type
(biketype_id, program_id, maker, model, bike_type)
VALUES
('BT1', 'P1', 'Trek', 'CityBike', 'Electric');

INSERT INTO bergen.station
(station_id, program_id, name, address, postal_code, latitude, longitude, capacity)
VALUES
('S1', 'P1', 'Test Station', 'Testveien 1', 5000, 60.3913, 5.3221, 10);

INSERT INTO bergen.station_dock
(dock_id, station_id, bike_id, dock_number, is_occupied, is_accepting_returns, is_accepting_renting, bike_type, last_updated)
VALUES
('D1', 'S1', NULL, 1, false, true, true, 'Electric', CURRENT_TIMESTAMP);

-- 2. Stored procedure: create_bicycle_proc

CREATE OR REPLACE PROCEDURE bergen.create_bicycle_proc(
    IN p_dock_id VARCHAR,
    IN p_biketype_id VARCHAR,
    IN p_year_acquired INT,
    INOUT p_bike_id VARCHAR DEFAULT NULL
)
LANGUAGE plpgsql
AS $$
DECLARE
    v_next_id INT;
BEGIN
    -- Validate foreign key reference: dock must exist
    PERFORM 1
    FROM bergen.station_dock
    WHERE dock_id = p_dock_id;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Invalid dock_id: % does not exist in bergen.station_dock', p_dock_id;
    END IF;

    -- Validate foreign key reference: bike type must exist
    PERFORM 1
    FROM bergen.bike_type
    WHERE biketype_id = p_biketype_id;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Invalid biketype_id: % does not exist in bergen.bike_type', p_biketype_id;
    END IF;

    -- Generate bike_id according to required format
    SELECT COUNT(*) + 1
    INTO v_next_id
    FROM bergen.bike;

    p_bike_id := 'bergen_bike_' || v_next_id;

    -- Insert bicycle
    INSERT INTO bergen.bike (bike_id, dock_id, biketype_id, year_acquired)
    VALUES (p_bike_id, p_dock_id, p_biketype_id, p_year_acquired);

EXCEPTION
    WHEN unique_violation THEN
        RAISE EXCEPTION 'Duplicate value error while creating bicycle.';
    WHEN raise_exception THEN
        RAISE;
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Unexpected error in create_bicycle_proc: %', SQLERRM;
END;
$$;

-- 3. Row-level trigger function

CREATE OR REPLACE FUNCTION bergen.check_year_acquired()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
    IF NEW.year_acquired > EXTRACT(YEAR FROM CURRENT_DATE) THEN
        RAISE EXCEPTION 'year_acquired cannot be in the future';
    END IF;

    RETURN NEW;
END;
$$;

-- 4. Row-level trigger

CREATE TRIGGER trg_check_year_acquired
BEFORE INSERT OR UPDATE ON bergen.bike
FOR EACH ROW
EXECUTE FUNCTION bergen.check_year_acquired();

-- 5. Statement-level trigger function

CREATE OR REPLACE FUNCTION bergen.bike_insert_statement_trigger()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
    RAISE NOTICE 'Insert statement executed on bike table';
    RETURN NULL;
END;
$$;

-- 6. Statement-level trigger

CREATE TRIGGER trg_bike_insert_statement
AFTER INSERT ON bergen.bike
FOR EACH STATEMENT
EXECUTE FUNCTION bergen.bike_insert_statement_trigger();

-- TESTS

-- 7. Test execution of stored procedure
DO $$
DECLARE
    v_bike_id VARCHAR := NULL;
BEGIN
    CALL bergen.create_bicycle_proc('D1', 'BT1', 2024, v_bike_id);
    RAISE NOTICE 'Created bike_id: %', v_bike_id;
END $$;

-- 8. Verify insert
SELECT * FROM bergen.bike;

-- 9. Invalid foreign key
DO $$
DECLARE
    v_bike_id VARCHAR := NULL;
BEGIN
    CALL bergen.create_bicycle_proc('D99', 'BT1', 2024, v_bike_id);
END $$;
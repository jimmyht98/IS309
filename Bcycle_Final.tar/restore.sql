--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.6
-- Dumped by pg_dump version 18.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "Bcycle_Final";
--
-- Name: Bcycle_Final; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "Bcycle_Final" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = icu LOCALE = 'en_US.UTF-8' ICU_LOCALE = 'en-US';


ALTER DATABASE "Bcycle_Final" OWNER TO postgres;

\unrestrict (null)
\connect "Bcycle_Final"
\restrict (null)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: bergen; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA bergen;


ALTER SCHEMA bergen OWNER TO pg_database_owner;

--
-- Name: SCHEMA bergen; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA bergen IS 'Schema for program "Bergen"';


--
-- Name: bike_insert_statement_trigger(); Type: FUNCTION; Schema: bergen; Owner: postgres
--

CREATE FUNCTION bergen.bike_insert_statement_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    RAISE NOTICE 'Insert statement executed on bike table';
    RETURN NULL;
END;
$$;


ALTER FUNCTION bergen.bike_insert_statement_trigger() OWNER TO postgres;

--
-- Name: check_date_acquired(); Type: FUNCTION; Schema: bergen; Owner: postgres
--

CREATE FUNCTION bergen.check_date_acquired() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF NEW.date_acquired > CURRENT_DATE THEN
        RAISE EXCEPTION 'date_acquired cannot be in the future';
    END IF;

    RETURN NEW;
END;
$$;


ALTER FUNCTION bergen.check_date_acquired() OWNER TO postgres;

--
-- Name: check_membership_dates(); Type: FUNCTION; Schema: bergen; Owner: postgres
--

CREATE FUNCTION bergen.check_membership_dates() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF NEW.expiration_time <= NEW.activation_time THEN
        RAISE EXCEPTION 'Expiration time must be later than activation time';
    END IF;

    RETURN NEW;
END;
$$;


ALTER FUNCTION bergen.check_membership_dates() OWNER TO postgres;

--
-- Name: create_account_sp(character varying, character varying, character varying, date, character varying, character varying, integer, character varying, character varying, character varying, character varying); Type: PROCEDURE; Schema: bergen; Owner: postgres
--

CREATE PROCEDURE bergen.create_account_sp(IN p_name character varying, IN p_surname character varying, IN p_email character varying, IN p_date_of_birth date, IN p_street character varying, IN p_city character varying, IN p_postal_code integer, IN p_state character varying, IN p_hashsalt character varying, IN p_passhash character varying, INOUT p_user_id character varying DEFAULT NULL::character varying)
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'postgres', 'pg_temp'
    AS $$
DECLARE
    v_user_id VARCHAR;
    v_next_id INT;
BEGIN
    SELECT COUNT(*) + 1
    INTO v_next_id
    FROM bergen.user_info;

    p_user_id := 'user_' || v_next_id;

    INSERT INTO bergen.user_info ( user_id,
        name, surname, email, date_of_birth,
        address, city, postal_code, state,
        total_trips, creation_date
    )
    VALUES ( p_user_id,
        p_name, p_surname, p_email, p_date_of_birth,
        p_street, p_city, p_postal_code, p_state,
        0, CURRENT_TIMESTAMP
    )
    RETURNING user_id INTO v_user_id;

    INSERT INTO bergen.user_auth (
        user_id, hashsalt, passhash, email
    )
    VALUES (
        v_user_id, p_hashsalt, p_passhash, p_email
    );

    p_user_id := v_user_id;

    RAISE NOTICE 'Account created successfully with user_id: %', v_user_id;

EXCEPTION
    WHEN unique_violation THEN
        RAISE EXCEPTION 'An account with email % already exists.', p_email;
    WHEN OTHERS THEN
        RAISE EXCEPTION 'An error occurred: %', SQLERRM;
END;
$$;


ALTER PROCEDURE bergen.create_account_sp(IN p_name character varying, IN p_surname character varying, IN p_email character varying, IN p_date_of_birth date, IN p_street character varying, IN p_city character varying, IN p_postal_code integer, IN p_state character varying, IN p_hashsalt character varying, IN p_passhash character varying, INOUT p_user_id character varying) OWNER TO postgres;

--
-- Name: create_bicycle_proc(character varying); Type: PROCEDURE; Schema: bergen; Owner: postgres
--

CREATE PROCEDURE bergen.create_bicycle_proc(IN p_bike_type_id character varying)
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_next_id INT;
    p_bike_id VARCHAR;
BEGIN
    -- Validate foreign key reference: bike type must exist
    PERFORM 1
    FROM bergen.bike_type
    WHERE bike_type_id = p_bike_type_id;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Invalid bike_type_id: % does not exist in bergen.bike_type', p_bike_type_id;
    END IF;

    -- Generate bike_id according to required format
    SELECT COUNT(*) + 1
    INTO v_next_id
    FROM bergen.bike;

    p_bike_id := 'bergen_bike_' || v_next_id;

    -- Insert bicycle
    INSERT INTO bergen.bike (bike_id, dock_id, bike_type_id)
    VALUES (p_bike_id, NULL, p_bike_type_id);

EXCEPTION
    WHEN unique_violation THEN
        RAISE EXCEPTION 'Duplicate value error while creating bicycle.';
    WHEN raise_exception THEN
        RAISE;
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Unexpected error in create_bicycle_proc: %', SQLERRM;
END;
$$;


ALTER PROCEDURE bergen.create_bicycle_proc(IN p_bike_type_id character varying) OWNER TO postgres;

--
-- Name: gen_station_id(character varying); Type: FUNCTION; Schema: bergen; Owner: postgres
--

CREATE FUNCTION bergen.gen_station_id(program_name character varying) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
DECLARE 
	station_id VARCHAR;
BEGIN
station_id := program_name || '_station_' || nextval('bergen.station_seq');
    RETURN  station_id;
END;
$$;


ALTER FUNCTION bergen.gen_station_id(program_name character varying) OWNER TO postgres;

--
-- Name: insert_new_station(character varying, character varying, integer, numeric, numeric, integer); Type: PROCEDURE; Schema: bergen; Owner: postgres
--

CREATE PROCEDURE bergen.insert_new_station(IN st_name character varying, IN st_address character varying, IN st_postal_code integer, IN st_latitude numeric, IN st_longitude numeric, IN st_capacity integer)
    LANGUAGE plpgsql
    AS $$
DECLARE
    rows_affected INT;
BEGIN 
    INSERT INTO bergen.station (station_id ,program_id, name, address, postal_code, latitude, longitude, total_capacity, available_docks) 
    SELECT bergen.gen_station_id(name), program_id, st_name, st_address, st_postal_code, st_latitude, st_longitude, st_capacity, st_capacity
    FROM bergen.program 
    WHERE program_id = 'bcycle_bergen';

    GET DIAGNOSTICS rows_affected = ROW_COUNT;

    IF rows_affected > 0 THEN
        RAISE NOTICE 'Suksess: % rad(er) satt inn.', rows_affected;
    ELSE
        RAISE WARNING 'Ingen rader satt inn! Sjekk om program_id "bcycle_bergen" eksisterer i bergen.program.';
    END IF;
END;
$$;


ALTER PROCEDURE bergen.insert_new_station(IN st_name character varying, IN st_address character varying, IN st_postal_code integer, IN st_latitude numeric, IN st_longitude numeric, IN st_capacity integer) OWNER TO postgres;

--
-- Name: membership_insert_statement_trigger(); Type: FUNCTION; Schema: bergen; Owner: postgres
--

CREATE FUNCTION bergen.membership_insert_statement_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    RAISE NOTICE 'Insert statement executed on bought_membership table';
    RETURN NULL;
END;
$$;


ALTER FUNCTION bergen.membership_insert_statement_trigger() OWNER TO postgres;

--
-- Name: purchase_membership_proc(character varying, character varying, boolean, timestamp with time zone, character varying); Type: PROCEDURE; Schema: bergen; Owner: postgres
--

CREATE PROCEDURE bergen.purchase_membership_proc(IN p_user_id character varying, IN p_membership_type character varying, IN p_is_active boolean, IN p_activation_time timestamp with time zone DEFAULT NULL::timestamp with time zone, INOUT p_purchase_id character varying DEFAULT NULL::character varying)
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_next_id INT;
    v_duration INT;
    v_activation_time TIMESTAMPTZ;
    v_expiration_time TIMESTAMPTZ;
BEGIN
    -- Validate that membership type exists
    PERFORM 1
    FROM bergen.membership
    WHERE membership_type = p_membership_type;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Invalid membership type: % does not exist in bergen.membership', p_membership_type;
    END IF;

    -- Validate that user exists
    PERFORM 1
    FROM bergen.user_info
    WHERE user_id = p_user_id;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'User does not exist: user_id % was not found in bergen.user_info', p_user_id;
    END IF;

        -- Generate purchase_id according to required format
    SELECT COUNT(*) + 1
    INTO v_next_id
    FROM bergen.bought_membership;

    p_purchase_id := 'purchase_' || v_next_id;

    -- Get duration from membership table
    SELECT duration
    INTO v_duration
    FROM bergen.membership
    WHERE membership_type = p_membership_type;

    -- Use current timestamp if activation time is not provided
    v_activation_time := COALESCE(p_activation_time, CURRENT_TIMESTAMP);

    -- Derive expiration time from activation_time + duration
    v_expiration_time := v_activation_time + (v_duration || ' days')::INTERVAL;

    -- Insert purchase
    INSERT INTO bergen.bought_membership (
        purchase_id,
        user_id,
        membership_type,
        is_active,
        purchase_time,
        activation_time,
        expiration_time
    )
    VALUES (
        p_purchase_id,
        p_user_id,
        p_membership_type,
        p_is_active,
        CURRENT_TIMESTAMP,
        v_activation_time,
        v_expiration_time
    )
    RETURNING purchase_id INTO p_purchase_id;

EXCEPTION
    WHEN unique_violation THEN
        RAISE EXCEPTION 'Duplicate value caused a unique violation while purchasing membership';
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Unexpected error in purchase_membership_proc: %', SQLERRM;
END;
$$;


ALTER PROCEDURE bergen.purchase_membership_proc(IN p_user_id character varying, IN p_membership_type character varying, IN p_is_active boolean, IN p_activation_time timestamp with time zone, INOUT p_purchase_id character varying) OWNER TO postgres;

--
-- Name: start_trip_sp(character varying, character varying, character varying, character varying, timestamp with time zone); Type: PROCEDURE; Schema: bergen; Owner: postgres
--

CREATE PROCEDURE bergen.start_trip_sp(IN p_user_id character varying, IN p_bike_id character varying, IN p_program_id character varying, IN p_start_station_id character varying, OUT p_trip_id character varying, IN p_start_time timestamp with time zone DEFAULT now())
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_battery_start  INTEGER;
    v_last_bike_lat  NUMERIC;
    v_last_bike_lon  NUMERIC;
    v_ss_prev        bergen.station_status%ROWTYPE;
    v_new_ssid       VARCHAR;
    v_new_bs_id      VARCHAR;
BEGIN
    -- 1) Check that the start station exists for the given program
    PERFORM 1
    FROM bergen.station
    WHERE station_id = p_start_station_id
      AND program_id = p_program_id;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'START_TRIP_SP: station % (program %) does not exist.',
            p_start_station_id, p_program_id;
    END IF;

    -- 2) Get the last bike status for the bike to be used in the trip
    SELECT bs.battery, bs.latitude, bs.longitude
    INTO   v_battery_start, v_last_bike_lat, v_last_bike_lon
    FROM   bergen.bike_status bs
    WHERE  bs.bike_id = p_bike_id
    ORDER  BY bs.last_updated DESC
    LIMIT  1;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'START_TRIP_SP: no status found for bike_id=%.', p_bike_id;
    END IF;

    -- 3) Generate a new trip_id
    SELECT 'trip_' || (COALESCE(MAX(CAST(SUBSTRING(ride_id FROM 6) AS INTEGER)), 0) + 1)::TEXT
    INTO   p_trip_id
    FROM   bergen.trip;

    -- 4) Insert the new trip with the starting information
    INSERT INTO bergen.trip (
        ride_id, user_id, bike_id, program_id,
        start_time, start_station_id, battery_start
    )
    VALUES (
        p_trip_id, p_user_id, p_bike_id, p_program_id,
        p_start_time, p_start_station_id, v_battery_start
    );

    -- 5) Generate a new bike_status_id
    SELECT 'bike_status_' || (COALESCE(MAX(CAST(SUBSTRING(bike_status_id FROM 13) AS INTEGER)), 0) + 1)::TEXT
    INTO   v_new_bs_id
    FROM   bergen.bike_status;

    -- 6) Mark the bike as in use with the new bike_status
    INSERT INTO bergen.bike_status (
        bike_status_id, bike_id, status,
        latitude, longitude,
        battery, remaining_range, total_distance, last_updated
    )
    VALUES (
        v_new_bs_id, p_bike_id, 'in_use',
        v_last_bike_lat, v_last_bike_lon,
        v_battery_start, NULL, 0, NOW()
    );

    -- 7) Get the last station_status information for the start station
    SELECT * INTO v_ss_prev
    FROM   bergen.station_status ss
    WHERE  ss.station_id = p_start_station_id
    ORDER  BY ss.last_updated DESC
    LIMIT  1;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'START_TRIP_SP: no station_status found for station_id=%.', p_start_station_id;
    END IF;

    -- 8) Generate new station_status_id
    SELECT 'station_status_' || (COALESCE(MAX(CAST(SUBSTRING(station_status_id FROM 16) AS INTEGER)), 0) + 1)::TEXT
    INTO   v_new_ssid
    FROM   bergen.station_status;

    -- 9) Insert new station_status
    INSERT INTO bergen.station_status (
        station_status_id, station_id, dock_id,
        available_docks,
        regular_bikes_available, electric_bikes_available,
        smart_bikes_available,   cargo_bikes_available,
        is_accepting_returns, is_accepting_renting,
        last_updated
    )
    VALUES (
        v_new_ssid,
        v_ss_prev.station_id,
        v_ss_prev.dock_id,
        v_ss_prev.available_docks + 1,
        GREATEST(v_ss_prev.regular_bikes_available - 1, 0),
        v_ss_prev.electric_bikes_available,
        v_ss_prev.smart_bikes_available,
        v_ss_prev.cargo_bikes_available,
        v_ss_prev.is_accepting_returns,
        v_ss_prev.is_accepting_renting,
        NOW()
    );

    -- 10) Set the bike's dock_id to NULL since it's now in use
    UPDATE bergen.bike
    SET dock_id = NULL
    WHERE bike_id = p_bike_id;

    RAISE NOTICE 'START_TRIP_SP: Trip % started for user % with bike % at station %.',
        p_trip_id, p_user_id, p_bike_id, p_start_station_id;
END;
$$;


ALTER PROCEDURE bergen.start_trip_sp(IN p_user_id character varying, IN p_bike_id character varying, IN p_program_id character varying, IN p_start_station_id character varying, OUT p_trip_id character varying, IN p_start_time timestamp with time zone) OWNER TO postgres;

--
-- Name: trg_func_gen_station_id(); Type: FUNCTION; Schema: bergen; Owner: postgres
--

CREATE FUNCTION bergen.trg_func_gen_station_id() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE 
    program_name VARCHAR;
BEGIN
	IF NEW.station_id IS NULL OR NEW.station_id = '' THEN
    SELECT name INTO program_name FROM bergen.program WHERE program_id = NEW.program_id;
        NEW.station_id := program_name || '_station_' || nextval('bergen.station_seq');
        RETURN NEW;
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION bergen.trg_func_gen_station_id() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: bike; Type: TABLE; Schema: bergen; Owner: postgres
--

CREATE TABLE bergen.bike (
    bike_id character varying(100) NOT NULL,
    dock_id character varying(100),
    bike_type_id character varying(100) NOT NULL,
    date_acquired date DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE bergen.bike OWNER TO postgres;

--
-- Name: bike_status; Type: TABLE; Schema: bergen; Owner: postgres
--

CREATE TABLE bergen.bike_status (
    bike_status_id character varying NOT NULL,
    bike_id character varying NOT NULL,
    status character varying NOT NULL,
    latitude numeric(9,7) NOT NULL,
    longitude numeric(9,7) NOT NULL,
    battery integer,
    remaining_range numeric,
    total_distance numeric NOT NULL,
    last_updated timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE bergen.bike_status OWNER TO postgres;

--
-- Name: bike_type; Type: TABLE; Schema: bergen; Owner: postgres
--

CREATE TABLE bergen.bike_type (
    bike_type_id character varying(100) NOT NULL,
    program_id character varying(100) NOT NULL,
    maker character varying(20) NOT NULL,
    model character varying(20) NOT NULL,
    bike_type character varying(10) NOT NULL
);


ALTER TABLE bergen.bike_type OWNER TO postgres;

--
-- Name: bought_membership; Type: TABLE; Schema: bergen; Owner: postgres
--

CREATE TABLE bergen.bought_membership (
    purchase_id character varying(100) NOT NULL,
    user_id character varying(100) NOT NULL,
    membership_type character varying(100) NOT NULL,
    is_active boolean NOT NULL,
    purchase_time timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    activation_time timestamp(3) with time zone NOT NULL,
    expiration_time timestamp(3) with time zone NOT NULL
);


ALTER TABLE bergen.bought_membership OWNER TO postgres;

--
-- Name: membership; Type: TABLE; Schema: bergen; Owner: postgres
--

CREATE TABLE bergen.membership (
    membership_type character varying(100) NOT NULL,
    price numeric(10,2) NOT NULL,
    duration integer NOT NULL
);


ALTER TABLE bergen.membership OWNER TO postgres;

--
-- Name: program; Type: TABLE; Schema: bergen; Owner: postgres
--

CREATE TABLE bergen.program (
    program_id character varying(100) NOT NULL,
    country_code character(2) NOT NULL,
    name character varying(30) NOT NULL,
    location character varying(20) NOT NULL,
    email character varying(40) NOT NULL,
    url character varying(100) NOT NULL,
    time_zone character varying(20) NOT NULL,
    phone character varying(20) NOT NULL,
    CONSTRAINT email_check CHECK (((email)::text ~* '^[A-Za-z0-9._+%-]+@[A-Za-z0-9.-]+[.][A-Za-z]+$'::text))
);


ALTER TABLE bergen.program OWNER TO postgres;

--
-- Name: station; Type: TABLE; Schema: bergen; Owner: postgres
--

CREATE TABLE bergen.station (
    station_id character varying(100) NOT NULL,
    program_id character varying(100) NOT NULL,
    name character varying(30) NOT NULL,
    address character varying(50) NOT NULL,
    postal_code smallint NOT NULL,
    latitude numeric(9,7) NOT NULL,
    longitude numeric(9,7) NOT NULL,
    total_capacity integer NOT NULL,
    available_docks integer NOT NULL,
    creation_date timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE bergen.station OWNER TO postgres;

--
-- Name: station_dock; Type: TABLE; Schema: bergen; Owner: postgres
--

CREATE TABLE bergen.station_dock (
    dock_id character varying(100) NOT NULL,
    station_id character varying(100) NOT NULL,
    dock_number integer NOT NULL,
    bike_id character varying(100),
    bike_type character varying(50),
    is_occupied boolean NOT NULL,
    is_accepting_returns boolean NOT NULL,
    is_accepting_renting boolean NOT NULL,
    last_updated timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE bergen.station_dock OWNER TO postgres;

--
-- Name: station_seq; Type: SEQUENCE; Schema: bergen; Owner: postgres
--

CREATE SEQUENCE bergen.station_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE bergen.station_seq OWNER TO postgres;

--
-- Name: station_status; Type: TABLE; Schema: bergen; Owner: postgres
--

CREATE TABLE bergen.station_status (
    station_status_id character varying(100) NOT NULL,
    station_id character varying(100) NOT NULL,
    dock_id character varying(100) NOT NULL,
    available_docks integer NOT NULL,
    regular_bikes_available integer NOT NULL,
    electric_bikes_available integer NOT NULL,
    smart_bikes_available integer NOT NULL,
    cargo_bikes_available integer NOT NULL,
    is_accepting_returns boolean NOT NULL,
    is_accepting_renting boolean NOT NULL,
    last_updated timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE bergen.station_status OWNER TO postgres;

--
-- Name: trip; Type: TABLE; Schema: bergen; Owner: postgres
--

CREATE TABLE bergen.trip (
    ride_id character varying(100) NOT NULL,
    user_id character varying(100) NOT NULL,
    bike_id character varying(100) NOT NULL,
    program_id character varying(100) NOT NULL,
    start_time timestamp(3) with time zone NOT NULL,
    end_time timestamp(3) with time zone,
    start_station_id character varying(100) NOT NULL,
    end_station_id character varying(100),
    trip_distance numeric,
    battery_start integer,
    battery_end integer,
    trip_cost numeric(5,2),
    trip_duration interval
);


ALTER TABLE bergen.trip OWNER TO postgres;

--
-- Name: user_auth; Type: TABLE; Schema: bergen; Owner: postgres
--

CREATE TABLE bergen.user_auth (
    user_id character varying(100) NOT NULL,
    hashsalt character varying NOT NULL,
    passhash character varying NOT NULL,
    email character varying NOT NULL
);


ALTER TABLE bergen.user_auth OWNER TO postgres;

--
-- Name: user_info; Type: TABLE; Schema: bergen; Owner: postgres
--

CREATE TABLE bergen.user_info (
    user_id character varying(100) NOT NULL,
    name character varying NOT NULL,
    surname character varying NOT NULL,
    email character varying NOT NULL,
    date_of_birth date NOT NULL,
    address character varying NOT NULL,
    city character varying NOT NULL,
    postal_code smallint NOT NULL,
    state character varying NOT NULL,
    total_trips integer NOT NULL,
    creation_date timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT birthday_check CHECK ((date_of_birth <= CURRENT_DATE)),
    CONSTRAINT email_check CHECK (((email)::text ~* '^[A-Za-z0-9._+%-]+@[A-Za-z0-9.-]+[.][A-Za-z]+$'::text)),
    CONSTRAINT trips_check CHECK ((total_trips >= 0))
);


ALTER TABLE bergen.user_info OWNER TO postgres;

--
-- Data for Name: bike; Type: TABLE DATA; Schema: bergen; Owner: postgres
--

COPY bergen.bike (bike_id, dock_id, bike_type_id, date_acquired) FROM stdin;
\.
COPY bergen.bike (bike_id, dock_id, bike_type_id, date_acquired) FROM '$$PATH$$/3493.dat';

--
-- Data for Name: bike_status; Type: TABLE DATA; Schema: bergen; Owner: postgres
--

COPY bergen.bike_status (bike_status_id, bike_id, status, latitude, longitude, battery, remaining_range, total_distance, last_updated) FROM stdin;
\.
COPY bergen.bike_status (bike_status_id, bike_id, status, latitude, longitude, battery, remaining_range, total_distance, last_updated) FROM '$$PATH$$/3494.dat';

--
-- Data for Name: bike_type; Type: TABLE DATA; Schema: bergen; Owner: postgres
--

COPY bergen.bike_type (bike_type_id, program_id, maker, model, bike_type) FROM stdin;
\.
COPY bergen.bike_type (bike_type_id, program_id, maker, model, bike_type) FROM '$$PATH$$/3492.dat';

--
-- Data for Name: bought_membership; Type: TABLE DATA; Schema: bergen; Owner: postgres
--

COPY bergen.bought_membership (purchase_id, user_id, membership_type, is_active, purchase_time, activation_time, expiration_time) FROM stdin;
\.
COPY bergen.bought_membership (purchase_id, user_id, membership_type, is_active, purchase_time, activation_time, expiration_time) FROM '$$PATH$$/3499.dat';

--
-- Data for Name: membership; Type: TABLE DATA; Schema: bergen; Owner: postgres
--

COPY bergen.membership (membership_type, price, duration) FROM stdin;
\.
COPY bergen.membership (membership_type, price, duration) FROM '$$PATH$$/3498.dat';

--
-- Data for Name: program; Type: TABLE DATA; Schema: bergen; Owner: postgres
--

COPY bergen.program (program_id, country_code, name, location, email, url, time_zone, phone) FROM stdin;
\.
COPY bergen.program (program_id, country_code, name, location, email, url, time_zone, phone) FROM '$$PATH$$/3488.dat';

--
-- Data for Name: station; Type: TABLE DATA; Schema: bergen; Owner: postgres
--

COPY bergen.station (station_id, program_id, name, address, postal_code, latitude, longitude, total_capacity, available_docks, creation_date) FROM stdin;
\.
COPY bergen.station (station_id, program_id, name, address, postal_code, latitude, longitude, total_capacity, available_docks, creation_date) FROM '$$PATH$$/3489.dat';

--
-- Data for Name: station_dock; Type: TABLE DATA; Schema: bergen; Owner: postgres
--

COPY bergen.station_dock (dock_id, station_id, dock_number, bike_id, bike_type, is_occupied, is_accepting_returns, is_accepting_renting, last_updated) FROM stdin;
\.
COPY bergen.station_dock (dock_id, station_id, dock_number, bike_id, bike_type, is_occupied, is_accepting_returns, is_accepting_renting, last_updated) FROM '$$PATH$$/3490.dat';

--
-- Data for Name: station_status; Type: TABLE DATA; Schema: bergen; Owner: postgres
--

COPY bergen.station_status (station_status_id, station_id, dock_id, available_docks, regular_bikes_available, electric_bikes_available, smart_bikes_available, cargo_bikes_available, is_accepting_returns, is_accepting_renting, last_updated) FROM stdin;
\.
COPY bergen.station_status (station_status_id, station_id, dock_id, available_docks, regular_bikes_available, electric_bikes_available, smart_bikes_available, cargo_bikes_available, is_accepting_returns, is_accepting_renting, last_updated) FROM '$$PATH$$/3491.dat';

--
-- Data for Name: trip; Type: TABLE DATA; Schema: bergen; Owner: postgres
--

COPY bergen.trip (ride_id, user_id, bike_id, program_id, start_time, end_time, start_station_id, end_station_id, trip_distance, battery_start, battery_end, trip_cost, trip_duration) FROM stdin;
\.
COPY bergen.trip (ride_id, user_id, bike_id, program_id, start_time, end_time, start_station_id, end_station_id, trip_distance, battery_start, battery_end, trip_cost, trip_duration) FROM '$$PATH$$/3495.dat';

--
-- Data for Name: user_auth; Type: TABLE DATA; Schema: bergen; Owner: postgres
--

COPY bergen.user_auth (user_id, hashsalt, passhash, email) FROM stdin;
\.
COPY bergen.user_auth (user_id, hashsalt, passhash, email) FROM '$$PATH$$/3497.dat';

--
-- Data for Name: user_info; Type: TABLE DATA; Schema: bergen; Owner: postgres
--

COPY bergen.user_info (user_id, name, surname, email, date_of_birth, address, city, postal_code, state, total_trips, creation_date) FROM stdin;
\.
COPY bergen.user_info (user_id, name, surname, email, date_of_birth, address, city, postal_code, state, total_trips, creation_date) FROM '$$PATH$$/3496.dat';

--
-- Name: station_seq; Type: SEQUENCE SET; Schema: bergen; Owner: postgres
--

SELECT pg_catalog.setval('bergen.station_seq', 3, true);


--
-- Name: bike bike_bike_id_bike_type_id_dock_id_key; Type: CONSTRAINT; Schema: bergen; Owner: postgres
--

ALTER TABLE ONLY bergen.bike
    ADD CONSTRAINT bike_bike_id_bike_type_id_dock_id_key UNIQUE (bike_id, bike_type_id, dock_id);


--
-- Name: bike bike_pkey; Type: CONSTRAINT; Schema: bergen; Owner: postgres
--

ALTER TABLE ONLY bergen.bike
    ADD CONSTRAINT bike_pkey PRIMARY KEY (bike_id);


--
-- Name: bike_status bike_status_bike_status_id_bike_id_key; Type: CONSTRAINT; Schema: bergen; Owner: postgres
--

ALTER TABLE ONLY bergen.bike_status
    ADD CONSTRAINT bike_status_bike_status_id_bike_id_key UNIQUE (bike_status_id, bike_id);


--
-- Name: bike_status bike_status_pkey; Type: CONSTRAINT; Schema: bergen; Owner: postgres
--

ALTER TABLE ONLY bergen.bike_status
    ADD CONSTRAINT bike_status_pkey PRIMARY KEY (bike_status_id);


--
-- Name: bike_type bike_type_bike_type_id_program_id_key; Type: CONSTRAINT; Schema: bergen; Owner: postgres
--

ALTER TABLE ONLY bergen.bike_type
    ADD CONSTRAINT bike_type_bike_type_id_program_id_key UNIQUE (bike_type_id, program_id);


--
-- Name: bike_type bike_type_pkey; Type: CONSTRAINT; Schema: bergen; Owner: postgres
--

ALTER TABLE ONLY bergen.bike_type
    ADD CONSTRAINT bike_type_pkey PRIMARY KEY (bike_type_id);


--
-- Name: bought_membership bought_membership_pkey; Type: CONSTRAINT; Schema: bergen; Owner: postgres
--

ALTER TABLE ONLY bergen.bought_membership
    ADD CONSTRAINT bought_membership_pkey PRIMARY KEY (purchase_id);


--
-- Name: bought_membership bought_membership_purchase_id_user_id_membership_type_key; Type: CONSTRAINT; Schema: bergen; Owner: postgres
--

ALTER TABLE ONLY bergen.bought_membership
    ADD CONSTRAINT bought_membership_purchase_id_user_id_membership_type_key UNIQUE (purchase_id, user_id, membership_type);


--
-- Name: membership membership_pkey; Type: CONSTRAINT; Schema: bergen; Owner: postgres
--

ALTER TABLE ONLY bergen.membership
    ADD CONSTRAINT membership_pkey PRIMARY KEY (membership_type);


--
-- Name: program program_pkey; Type: CONSTRAINT; Schema: bergen; Owner: postgres
--

ALTER TABLE ONLY bergen.program
    ADD CONSTRAINT program_pkey PRIMARY KEY (program_id);


--
-- Name: station_dock station_dock_dock_id_station_id_bike_id_key; Type: CONSTRAINT; Schema: bergen; Owner: postgres
--

ALTER TABLE ONLY bergen.station_dock
    ADD CONSTRAINT station_dock_dock_id_station_id_bike_id_key UNIQUE (dock_id, station_id, bike_id);


--
-- Name: station_dock station_dock_pkey; Type: CONSTRAINT; Schema: bergen; Owner: postgres
--

ALTER TABLE ONLY bergen.station_dock
    ADD CONSTRAINT station_dock_pkey PRIMARY KEY (dock_id);


--
-- Name: station station_pkey; Type: CONSTRAINT; Schema: bergen; Owner: postgres
--

ALTER TABLE ONLY bergen.station
    ADD CONSTRAINT station_pkey PRIMARY KEY (station_id);


--
-- Name: station station_station_id_program_id_key; Type: CONSTRAINT; Schema: bergen; Owner: postgres
--

ALTER TABLE ONLY bergen.station
    ADD CONSTRAINT station_station_id_program_id_key UNIQUE (station_id, program_id);


--
-- Name: station_status station_status_pkey; Type: CONSTRAINT; Schema: bergen; Owner: postgres
--

ALTER TABLE ONLY bergen.station_status
    ADD CONSTRAINT station_status_pkey PRIMARY KEY (station_status_id);


--
-- Name: station_status station_status_station_status_id_station_id_dock_id_key; Type: CONSTRAINT; Schema: bergen; Owner: postgres
--

ALTER TABLE ONLY bergen.station_status
    ADD CONSTRAINT station_status_station_status_id_station_id_dock_id_key UNIQUE (station_status_id, station_id, dock_id);


--
-- Name: trip trip_pkey; Type: CONSTRAINT; Schema: bergen; Owner: postgres
--

ALTER TABLE ONLY bergen.trip
    ADD CONSTRAINT trip_pkey PRIMARY KEY (ride_id);


--
-- Name: trip trip_ride_id_user_id_bike_id_program_id_key; Type: CONSTRAINT; Schema: bergen; Owner: postgres
--

ALTER TABLE ONLY bergen.trip
    ADD CONSTRAINT trip_ride_id_user_id_bike_id_program_id_key UNIQUE (ride_id, user_id, bike_id, program_id);


--
-- Name: user_auth user_auth_pkey; Type: CONSTRAINT; Schema: bergen; Owner: postgres
--

ALTER TABLE ONLY bergen.user_auth
    ADD CONSTRAINT user_auth_pkey PRIMARY KEY (user_id);


--
-- Name: user_auth user_auth_user_id_email_key; Type: CONSTRAINT; Schema: bergen; Owner: postgres
--

ALTER TABLE ONLY bergen.user_auth
    ADD CONSTRAINT user_auth_user_id_email_key UNIQUE (user_id, email);


--
-- Name: user_info user_info_pkey; Type: CONSTRAINT; Schema: bergen; Owner: postgres
--

ALTER TABLE ONLY bergen.user_info
    ADD CONSTRAINT user_info_pkey PRIMARY KEY (user_id);


--
-- Name: user_info user_info_user_id_email_key; Type: CONSTRAINT; Schema: bergen; Owner: postgres
--

ALTER TABLE ONLY bergen.user_info
    ADD CONSTRAINT user_info_user_id_email_key UNIQUE (user_id, email);


--
-- Name: bike trg_bike_insert_statement; Type: TRIGGER; Schema: bergen; Owner: postgres
--

CREATE TRIGGER trg_bike_insert_statement AFTER INSERT ON bergen.bike FOR EACH STATEMENT EXECUTE FUNCTION bergen.bike_insert_statement_trigger();


--
-- Name: bike trg_check_date_acquired; Type: TRIGGER; Schema: bergen; Owner: postgres
--

CREATE TRIGGER trg_check_date_acquired BEFORE INSERT OR UPDATE ON bergen.bike FOR EACH ROW EXECUTE FUNCTION bergen.check_date_acquired();


--
-- Name: bought_membership trg_check_membership_dates; Type: TRIGGER; Schema: bergen; Owner: postgres
--

CREATE TRIGGER trg_check_membership_dates BEFORE INSERT OR UPDATE ON bergen.bought_membership FOR EACH ROW EXECUTE FUNCTION bergen.check_membership_dates();


--
-- Name: bought_membership trg_membership_insert_statement; Type: TRIGGER; Schema: bergen; Owner: postgres
--

CREATE TRIGGER trg_membership_insert_statement AFTER INSERT ON bergen.bought_membership FOR EACH STATEMENT EXECUTE FUNCTION bergen.membership_insert_statement_trigger();


--
-- Name: station trg_station_id; Type: TRIGGER; Schema: bergen; Owner: postgres
--

CREATE TRIGGER trg_station_id BEFORE INSERT ON bergen.station FOR EACH ROW EXECUTE FUNCTION bergen.trg_func_gen_station_id();


--
-- Name: bike_status bike_fk; Type: FK CONSTRAINT; Schema: bergen; Owner: postgres
--

ALTER TABLE ONLY bergen.bike_status
    ADD CONSTRAINT bike_fk FOREIGN KEY (bike_id) REFERENCES bergen.bike(bike_id);


--
-- Name: station_dock bike_fk; Type: FK CONSTRAINT; Schema: bergen; Owner: postgres
--

ALTER TABLE ONLY bergen.station_dock
    ADD CONSTRAINT bike_fk FOREIGN KEY (bike_id) REFERENCES bergen.bike(bike_id);


--
-- Name: trip bike_fk; Type: FK CONSTRAINT; Schema: bergen; Owner: postgres
--

ALTER TABLE ONLY bergen.trip
    ADD CONSTRAINT bike_fk FOREIGN KEY (bike_id) REFERENCES bergen.bike(bike_id);


--
-- Name: bike bike_type_fk; Type: FK CONSTRAINT; Schema: bergen; Owner: postgres
--

ALTER TABLE ONLY bergen.bike
    ADD CONSTRAINT bike_type_fk FOREIGN KEY (bike_type_id) REFERENCES bergen.bike_type(bike_type_id);


--
-- Name: bike dock_fk; Type: FK CONSTRAINT; Schema: bergen; Owner: postgres
--

ALTER TABLE ONLY bergen.bike
    ADD CONSTRAINT dock_fk FOREIGN KEY (dock_id) REFERENCES bergen.station_dock(dock_id);


--
-- Name: station_status dock_fk; Type: FK CONSTRAINT; Schema: bergen; Owner: postgres
--

ALTER TABLE ONLY bergen.station_status
    ADD CONSTRAINT dock_fk FOREIGN KEY (dock_id) REFERENCES bergen.station_dock(dock_id);


--
-- Name: trip end_station_fk; Type: FK CONSTRAINT; Schema: bergen; Owner: postgres
--

ALTER TABLE ONLY bergen.trip
    ADD CONSTRAINT end_station_fk FOREIGN KEY (end_station_id) REFERENCES bergen.station(station_id);


--
-- Name: bought_membership membership_fk; Type: FK CONSTRAINT; Schema: bergen; Owner: postgres
--

ALTER TABLE ONLY bergen.bought_membership
    ADD CONSTRAINT membership_fk FOREIGN KEY (membership_type) REFERENCES bergen.membership(membership_type);


--
-- Name: bike_type program_fk; Type: FK CONSTRAINT; Schema: bergen; Owner: postgres
--

ALTER TABLE ONLY bergen.bike_type
    ADD CONSTRAINT program_fk FOREIGN KEY (program_id) REFERENCES bergen.program(program_id);


--
-- Name: station program_fk; Type: FK CONSTRAINT; Schema: bergen; Owner: postgres
--

ALTER TABLE ONLY bergen.station
    ADD CONSTRAINT program_fk FOREIGN KEY (program_id) REFERENCES bergen.program(program_id);


--
-- Name: trip program_fk; Type: FK CONSTRAINT; Schema: bergen; Owner: postgres
--

ALTER TABLE ONLY bergen.trip
    ADD CONSTRAINT program_fk FOREIGN KEY (program_id) REFERENCES bergen.program(program_id);


--
-- Name: trip start_station_fk; Type: FK CONSTRAINT; Schema: bergen; Owner: postgres
--

ALTER TABLE ONLY bergen.trip
    ADD CONSTRAINT start_station_fk FOREIGN KEY (start_station_id) REFERENCES bergen.station(station_id);


--
-- Name: station_dock station_fk; Type: FK CONSTRAINT; Schema: bergen; Owner: postgres
--

ALTER TABLE ONLY bergen.station_dock
    ADD CONSTRAINT station_fk FOREIGN KEY (station_id) REFERENCES bergen.station(station_id);


--
-- Name: station_status station_fk; Type: FK CONSTRAINT; Schema: bergen; Owner: postgres
--

ALTER TABLE ONLY bergen.station_status
    ADD CONSTRAINT station_fk FOREIGN KEY (station_id) REFERENCES bergen.station(station_id);


--
-- Name: bought_membership user_fk; Type: FK CONSTRAINT; Schema: bergen; Owner: postgres
--

ALTER TABLE ONLY bergen.bought_membership
    ADD CONSTRAINT user_fk FOREIGN KEY (user_id) REFERENCES bergen.user_info(user_id);


--
-- Name: trip user_fk; Type: FK CONSTRAINT; Schema: bergen; Owner: postgres
--

ALTER TABLE ONLY bergen.trip
    ADD CONSTRAINT user_fk FOREIGN KEY (user_id) REFERENCES bergen.user_info(user_id);


--
-- Name: user_auth user_fk; Type: FK CONSTRAINT; Schema: bergen; Owner: postgres
--

ALTER TABLE ONLY bergen.user_auth
    ADD CONSTRAINT user_fk FOREIGN KEY (user_id) REFERENCES bergen.user_info(user_id);


--
-- Name: SCHEMA bergen; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT USAGE ON SCHEMA bergen TO PUBLIC;


--
-- PostgreSQL database dump complete
--

